"use client";

import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useMutation } from "@tanstack/react-query";
import { artisanTermsSchema, ArtisanTermsInput } from "@/lib/schemas";
import { apiClient, handleApiError } from "@/lib/api-client";
import { useAuthStore } from "@/stores/auth-store";
import { Checkbox } from "@/components/Checkbox";
import { Button } from "@/components/Button";
import { ProgressSteps } from "@/components/ProgressSteps";

const STEPS = [
  { number: 1, label: "Compte" },
  { number: 2, label: "Profil" },
  { number: 3, label: "Identité" },
  { number: 4, label: "CGU" },
];

const ARTISAN_CGU_TEXT = `
CONDITIONS GÉNÉRALES D'UTILISATION ARTISAN

Article 1 - Objet
Les présentes Conditions Générales d'Utilisation (CGU) ont pour objet de définir les modalités et conditions dans lesquelles les Artisans peuvent s'inscrire et utiliser la plateforme Artisan Marketplace.

Article 2 - Inscription et Vérification
2.1 L'inscription en tant qu'Artisan nécessite la fourniture d'informations véridiques et complètes.
2.2 Une vérification d'identité est obligatoire pour activer votre compte professionnel.
2.3 Vous vous engagez à maintenir vos informations à jour.

Article 3 - Obligations de l'Artisan
3.1 Vous vous engagez à fournir des services de qualité conforme à votre description.
3.2 Vous devez respecter les délais annoncés pour la réalisation des prestations.
3.3 Vous êtes responsable de la qualité et de la conformité de vos services.
3.4 Vous devez être en règle avec toutes les obligations légales et fiscales liées à votre activité.

Article 4 - Tarification et Commission
4.1 Vous fixez librement vos tarifs pour chaque prestation.
4.2 Une commission de 15% est prélevée sur chaque transaction réalisée via la plateforme.
4.3 Les paiements sont effectués selon les modalités définies dans votre espace professionnel.

Article 5 - Responsabilité
5.1 Vous êtes seul responsable des services que vous proposez et réalisez.
5.2 Vous devez disposer d'une assurance professionnelle couvrant votre activité.
5.3 La plateforme ne peut être tenue responsable des litiges entre vous et vos clients.

Article 6 - Propriété Intellectuelle
6.1 Vous conservez tous les droits sur vos créations et réalisations.
6.2 En publiant du contenu (photos, descriptions), vous accordez à la plateforme le droit de l'utiliser à des fins promotionnelles.

Article 7 - Résiliation
7.1 Vous pouvez résilier votre compte à tout moment depuis votre espace professionnel.
7.2 La plateforme se réserve le droit de suspendre ou résilier votre compte en cas de manquement aux présentes CGU.

Article 8 - Protection des Données
8.1 Vos données personnelles sont traitées conformément à notre Politique de Confidentialité.
8.2 Vous disposez d'un droit d'accès, de rectification et de suppression de vos données.

Article 9 - Modification des CGU
La plateforme se réserve le droit de modifier les présentes CGU. Vous serez informé de toute modification majeure.

Article 10 - Loi Applicable
Les présentes CGU sont soumises au droit français. Tout litige sera porté devant les tribunaux compétents.

Dernière mise à jour : Janvier 2026
`;

export default function RegisterArtisanStep4Page() {
  const router = useRouter();
  const { isAuthenticated, updateUser } = useAuthStore();

  // Rediriger si pas authentifié
  React.useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth/register/artisan/step-1");
    }
  }, [isAuthenticated, router]);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ArtisanTermsInput>({
    resolver: zodResolver(artisanTermsSchema),
    mode: "onBlur",
  });

  const finalizeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiClient.post("/api/users/artisan/finalize");
      return response.data;
    },
    onSuccess: (data) => {
      // Mettre à jour le store avec le compte activé
      updateUser({ isVerified: true });

      // Redirection vers le dashboard artisan
      router.push("/dashboard/artisan");
    },
    onError: (error: any) => {
      const apiError = handleApiError(error);
      alert(apiError.message);
    },
  });

  const onSubmit = () => {
    finalizeMutation.mutate();
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 flex items-center justify-center p-4">
      <div className="w-full max-w-3xl">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Progress Steps */}
          <ProgressSteps steps={STEPS} currentStep={4} />

          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Finalisation - Étape 4/4
            </h1>
            <p className="text-gray-600">
              Dernière étape avant d'activer votre compte professionnel
            </p>
          </div>

          {/* CGU Content */}
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              📜 Conditions Générales d'Utilisation Artisan
            </h2>

            <div className="border-2 border-gray-300 rounded-lg p-6 h-96 overflow-y-auto bg-gray-50">
              <pre className="whitespace-pre-wrap text-sm text-gray-700 font-sans">
                {ARTISAN_CGU_TEXT}
              </pre>
            </div>
          </div>

          {/* Formulaire */}
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {/* Checkbox CGU */}
            <div className="bg-purple-50 border-2 border-purple-200 rounded-lg p-4">
              <Checkbox
                label={
                  <span className="text-base">
                    J'ai lu et j'accepte les Conditions Générales d'Utilisation
                    Artisan. Je confirme être en règle avec mes obligations
                    légales et fiscales.
                  </span>
                }
                error={errors.acceptArtisanTerms?.message}
                {...register("acceptArtisanTerms")}
              />
            </div>

            {/* Info box */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <svg
                  className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                    clipRule="evenodd"
                  />
                </svg>
                <div>
                  <h3 className="font-semibold text-green-900 mb-1">
                    🎉 Vous y êtes presque !
                  </h3>
                  <p className="text-sm text-green-800">
                    Après validation, votre compte professionnel sera activé et
                    vous pourrez commencer à proposer vos services à nos
                    clients.
                  </p>
                </div>
              </div>
            </div>

            {/* Boutons */}
            <div className="flex gap-4 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => router.push("/auth/register/artisan/step-3")}
                className="flex-1"
              >
                Retour
              </Button>

              <Button
                type="submit"
                className="flex-1"
                size="lg"
                isLoading={finalizeMutation.isPending}
              >
                ✅ Activer mon compte
              </Button>
            </div>
          </form>

          {/* Footer */}
          <div className="mt-6 text-center">
            <p className="text-xs text-gray-500">
              En validant, vous acceptez que vos informations soient vérifiées
              par notre équipe avant activation définitive.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
