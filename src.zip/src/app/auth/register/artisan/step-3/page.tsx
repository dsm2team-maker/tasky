"use client";

import React, { useState, useRef, useCallback } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useMutation } from "@tanstack/react-query";
import Webcam from "react-webcam";
import {
  identityVerificationSchema,
  IdentityVerificationInput,
} from "@/lib/schemas";
import { apiClientUpload, handleApiError } from "@/lib/api-client";
import { useAuthStore } from "@/stores/auth-store";
import { Button } from "@/components/Button";
import { FileUpload } from "@/components/FileUpload";
import { ProgressSteps } from "@/components/ProgressSteps";

const STEPS = [
  { number: 1, label: "Compte" },
  { number: 2, label: "Profil" },
  { number: 3, label: "Identité" },
  { number: 4, label: "CGU" },
];

export default function RegisterArtisanStep3Page() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const [uploadMethod, setUploadMethod] = useState<"file" | "camera">("file");
  const [showCamera, setShowCamera] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const webcamRef = useRef<Webcam>(null);

  // Rediriger si pas authentifié
  React.useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth/register/artisan/step-1");
    }
  }, [isAuthenticated, router]);

  const {
    handleSubmit,
    control,
    setValue,
    watch,
    formState: { errors },
  } = useForm<IdentityVerificationInput>({
    resolver: zodResolver(identityVerificationSchema),
    mode: "onBlur",
    defaultValues: {
      documentType: "CNI",
    },
  });

  const documentType = watch("documentType");

  const verifyMutation = useMutation({
    mutationFn: async (data: IdentityVerificationInput) => {
      const formData = new FormData();
      formData.append("documentType", data.documentType);
      formData.append("identityDocument", data.identityDocument);

      const response = await apiClientUpload.post(
        "/api/users/verify-identity",
        formData,
      );
      return response.data;
    },
    onSuccess: () => {
      router.push("/auth/register/artisan/step-4");
    },
    onError: (error: any) => {
      const apiError = handleApiError(error);
      alert(apiError.message);
    },
  });

  // Capturer une photo avec la webcam
  const capturePhoto = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      setCapturedImage(imageSrc);
      setShowCamera(false);

      // Convertir base64 en File
      fetch(imageSrc)
        .then((res) => res.blob())
        .then((blob) => {
          const file = new File([blob], "identity-document.jpg", {
            type: "image/jpeg",
          });
          setValue("identityDocument", file);
        });
    }
  }, [setValue]);

  const onSubmit = (data: IdentityVerificationInput) => {
    verifyMutation.mutate(data);
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Progress Steps */}
          <ProgressSteps steps={STEPS} currentStep={3} />

          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Vérification d'identité - Étape 3/4
            </h1>
            <p className="text-gray-600">
              Pour la sécurité de tous, nous devons vérifier votre identité
            </p>
          </div>

          {/* Formulaire */}
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {/* Type de document */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Type de document
                <span className="text-red-500 ml-1">*</span>
              </label>
              <Controller
                name="documentType"
                control={control}
                render={({ field }) => (
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      type="button"
                      onClick={() => field.onChange("CNI")}
                      className={`p-4 border-2 rounded-lg text-center transition-all ${
                        field.value === "CNI"
                          ? "border-purple-600 bg-purple-50"
                          : "border-gray-300 hover:border-purple-400"
                      }`}
                    >
                      <div className="font-semibold">Carte d'identité</div>
                      <div className="text-sm text-gray-500 mt-1">CNI</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => field.onChange("PASSPORT")}
                      className={`p-4 border-2 rounded-lg text-center transition-all ${
                        field.value === "PASSPORT"
                          ? "border-purple-600 bg-purple-50"
                          : "border-gray-300 hover:border-purple-400"
                      }`}
                    >
                      <div className="font-semibold">Passeport</div>
                      <div className="text-sm text-gray-500 mt-1">Passport</div>
                    </button>
                  </div>
                )}
              />
            </div>

            {/* Instructions */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-semibold text-blue-900 mb-2">
                📋 Instructions importantes
              </h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>
                  • Photographiez uniquement le <strong>RECTO</strong> du
                  document
                </li>
                <li>
                  • Assurez-vous que toutes les informations sont lisibles
                </li>
                <li>• Évitez les reflets et les zones floues</li>
                <li>• Le document doit être en cours de validité</li>
              </ul>
            </div>

            {/* Méthode d'upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Méthode de capture
              </label>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <button
                  type="button"
                  onClick={() => {
                    setUploadMethod("file");
                    setShowCamera(false);
                  }}
                  className={`p-3 border-2 rounded-lg transition-all ${
                    uploadMethod === "file"
                      ? "border-purple-600 bg-purple-50"
                      : "border-gray-300"
                  }`}
                >
                  <svg
                    className="w-6 h-6 mx-auto mb-1"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
                    />
                  </svg>
                  <span className="text-sm font-medium">
                    Importer un fichier
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setUploadMethod("camera");
                    setShowCamera(true);
                  }}
                  className={`p-3 border-2 rounded-lg transition-all ${
                    uploadMethod === "camera"
                      ? "border-purple-600 bg-purple-50"
                      : "border-gray-300"
                  }`}
                >
                  <svg
                    className="w-6 h-6 mx-auto mb-1"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                  </svg>
                  <span className="text-sm font-medium">Prendre une photo</span>
                </button>
              </div>

              {/* Upload fichier */}
              {uploadMethod === "file" && !capturedImage && (
                <Controller
                  name="identityDocument"
                  control={control}
                  render={({ field }) => (
                    <FileUpload
                      accept="image/jpeg,image/png,image/webp,application/pdf"
                      maxSize={10}
                      error={errors.identityDocument?.message}
                      onChange={field.onChange}
                    />
                  )}
                />
              )}

              {/* Webcam */}
              {showCamera && !capturedImage && (
                <div className="space-y-4">
                  <div className="relative rounded-lg overflow-hidden bg-black">
                    <Webcam
                      ref={webcamRef}
                      audio={false}
                      screenshotFormat="image/jpeg"
                      className="w-full"
                      videoConstraints={{
                        facingMode: "environment",
                      }}
                    />
                  </div>
                  <div className="flex gap-3">
                    <Button
                      type="button"
                      onClick={capturePhoto}
                      className="flex-1"
                    >
                      📸 Capturer
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowCamera(false)}
                    >
                      Annuler
                    </Button>
                  </div>
                </div>
              )}

              {/* Image capturée */}
              {capturedImage && (
                <div className="space-y-3">
                  <img
                    src={capturedImage}
                    alt="Document capturé"
                    className="w-full rounded-lg border-2 border-gray-300"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setCapturedImage(null);
                      setShowCamera(true);
                    }}
                    fullWidth
                  >
                    Reprendre la photo
                  </Button>
                </div>
              )}
            </div>

            {/* Boutons */}
            <div className="flex gap-4 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => router.push("/auth/register/artisan/step-2")}
                className="flex-1"
              >
                Retour
              </Button>

              <Button
                type="submit"
                className="flex-1"
                size="lg"
                isLoading={verifyMutation.isPending}
              >
                Continuer
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
