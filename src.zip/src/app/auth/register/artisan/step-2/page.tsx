"use client";

import React, { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useMutation } from "@tanstack/react-query";
import { artisanProfileSchema, ArtisanProfileInput } from "@/lib/schemas";
import { apiClientUpload, handleApiError } from "@/lib/api-client";
import { useAuthStore } from "@/stores/auth-store";
import { Input } from "@/components/Input";
import { Button } from "@/components/Button";
import { FileUpload } from "@/components/FileUpload";
import { ProgressSteps } from "@/components/ProgressSteps";

const STEPS = [
  { number: 1, label: "Compte" },
  { number: 2, label: "Profil" },
  { number: 3, label: "Identité" },
  { number: 4, label: "CGU" },
];

export default function RegisterArtisanStep2Page() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const [charCount, setCharCount] = useState(0);

  // Rediriger si pas authentifié
  React.useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth/register/artisan/step-1");
    }
  }, [isAuthenticated, router]);

  const {
    register,
    handleSubmit,
    control,
    watch,
    formState: { errors },
  } = useForm<ArtisanProfileInput>({
    resolver: zodResolver(artisanProfileSchema),
    mode: "onBlur",
  });

  const bioValue = watch("bio");
  React.useEffect(() => {
    setCharCount(bioValue?.length || 0);
  }, [bioValue]);

  const profileMutation = useMutation({
    mutationFn: async (data: ArtisanProfileInput) => {
      const formData = new FormData();
      formData.append("firstName", data.firstName);
      formData.append("lastName", data.lastName);
      formData.append("bio", data.bio);
      formData.append("postalCode", data.postalCode);
      formData.append("profilePicture", data.profilePicture);

      const response = await apiClientUpload.post(
        "/api/users/artisan/profile",
        formData,
      );
      return response.data;
    },
    onSuccess: () => {
      router.push("/auth/register/artisan/step-3");
    },
    onError: (error: any) => {
      const apiError = handleApiError(error);
      alert(apiError.message);
    },
  });

  const onSubmit = (data: ArtisanProfileInput) => {
    profileMutation.mutate(data);
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          {/* Progress Steps */}
          <ProgressSteps steps={STEPS} currentStep={2} />

          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Complétez votre profil - Étape 2/4
            </h1>
            <p className="text-gray-600">
              Ces informations seront visibles par vos futurs clients
            </p>
          </div>

          {/* Formulaire */}
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {/* Photo de profil */}
            <Controller
              name="profilePicture"
              control={control}
              render={({ field }) => (
                <FileUpload
                  label="Photo de profil"
                  accept="image/jpeg,image/png,image/webp"
                  maxSize={5}
                  error={errors.profilePicture?.message}
                  onChange={field.onChange}
                />
              )}
            />

            {/* Prénom & Nom */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Prénom"
                type="text"
                placeholder="Jean"
                error={errors.firstName?.message}
                {...register("firstName")}
              />

              <Input
                label="Nom"
                type="text"
                placeholder="Dupont"
                error={errors.lastName?.message}
                {...register("lastName")}
              />
            </div>

            {/* Code postal */}
            <Input
              label="Code postal"
              type="text"
              placeholder="75001"
              error={errors.postalCode?.message}
              helperText="Pour vous mettre en relation avec des clients à proximité"
              {...register("postalCode")}
              icon={
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
              }
            />

            {/* Bio */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">
                Biographie
                <span className="text-red-500 ml-1">*</span>
              </label>
              <textarea
                placeholder="Présentez votre savoir-faire, votre expérience et ce qui vous passionne dans votre métier..."
                rows={5}
                maxLength={500}
                className={`w-full px-4 py-2.5 border rounded-lg text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 resize-none ${
                  errors.bio ? "border-red-500" : "border-gray-300"
                }`}
                {...register("bio")}
              />
              <div className="flex justify-between items-center mt-1.5">
                {errors.bio ? (
                  <p className="text-sm text-red-600 flex items-center gap-1">
                    <svg
                      className="w-4 h-4"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
                        clipRule="evenodd"
                      />
                    </svg>
                    {errors.bio.message}
                  </p>
                ) : (
                  <span className="text-sm text-gray-500">
                    Min. 20 caractères
                  </span>
                )}
                <span
                  className={`text-sm ${charCount > 500 ? "text-red-600" : "text-gray-500"}`}
                >
                  {charCount}/500
                </span>
              </div>
            </div>

            {/* Boutons */}
            <div className="flex gap-4 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => router.push("/auth/register/artisan/step-1")}
                className="flex-1"
              >
                Retour
              </Button>

              <Button
                type="submit"
                className="flex-1"
                size="lg"
                isLoading={profileMutation.isPending}
              >
                Continuer
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
