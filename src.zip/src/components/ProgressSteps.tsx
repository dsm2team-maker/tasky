// Composant pour afficher la progression des étapes
import React from "react";
import { cn } from "@/lib/utils";

interface Step {
  number: number;
  label: string;
}

interface ProgressStepsProps {
  steps: Step[];
  currentStep: number;
}

export const ProgressSteps: React.FC<ProgressStepsProps> = ({
  steps,
  currentStep,
}) => {
  return (
    <div className="w-full py-6">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <React.Fragment key={step.number}>
            <div className="flex flex-col items-center flex-1">
              <div
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center",
                  "font-semibold text-sm transition-all duration-300",
                  step.number < currentStep && "bg-green-500 text-white",
                  step.number === currentStep &&
                    "bg-blue-600 text-white ring-4 ring-blue-100",
                  step.number > currentStep && "bg-gray-200 text-gray-500",
                )}
              >
                {step.number < currentStep ? (
                  <svg
                    className="w-5 h-5"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                ) : (
                  step.number
                )}
              </div>

              <span
                className={cn(
                  "mt-2 text-xs font-medium text-center",
                  step.number === currentStep && "text-blue-600",
                  step.number !== currentStep && "text-gray-500",
                )}
              >
                {step.label}
              </span>
            </div>

            {index < steps.length - 1 && (
              <div
                className={cn(
                  "flex-1 h-1 mx-2 rounded transition-all duration-300",
                  step.number < currentStep ? "bg-green-500" : "bg-gray-200",
                )}
              />
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};
